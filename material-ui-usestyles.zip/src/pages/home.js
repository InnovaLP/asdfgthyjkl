import { useStyles } from "@andywer/style-hook";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import React from "react";
import { Link } from "react-router-dom";

import PageSection from "../components/pagesection";

function Heart() {
  return (
    <span role="img" aria-label="Heart">
      ❤️
    </span>
  );
}

function Home() {
  const classNames = useStyles({
    section: {
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
      textAlign: "center"
    },
    title: {
      marginBottom: theme => theme.spacing.unit * 2
    },
    subtitle: {
      marginBottom: theme => theme.spacing.unit * 4
    }
  });
  return (
    <PageSection className={classNames.section}>
      <Typography className={classNames.title} component="h1" variant="h5">
        Material UI + useStyles() = <Heart />
      </Typography>
      <Typography className={classNames.subtitle} component="h2" variant="h6">
        Start editing the play ground or click around!
      </Typography>
      <Link to="/hacker-news">
        <Button color="primary" variant="contained">
          Hacker News Top Stories
        </Button>
      </Link>
    </PageSection>
  );
}

export default Home;
