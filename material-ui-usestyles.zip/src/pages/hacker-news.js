import { useStyle, useStyles } from "@andywer/style-hook";
import CircularProgress from "@material-ui/core/CircularProgress";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import Typography from "@material-ui/core/Typography";
import React, { useEffect, useState } from "react";

import PageSection from "../components/pagesection";

async function fetchTopStories(count = 20) {
  const topStoriesIdsResponse = await fetch(
    "https://hacker-news.firebaseio.com/v0/topstories.json"
  );
  const topStoryIds = await topStoriesIdsResponse.json();
  const topStoryResponses = await Promise.all(
    topStoryIds
      .slice(0, count)
      .map(storyId =>
        fetch(`https://hacker-news.firebaseio.com/v0/item/${storyId}.json`)
      )
  );
  const topStories = await Promise.all(
    topStoryResponses.map(response => response.json())
  );
  return topStories;
}

function Spinner() {
  const className = useStyle({
    margin: "20vh auto",
    textAlign: "center"
  });
  return (
    <div className={className}>
      <CircularProgress />
    </div>
  );
}

function HackerNews() {
  const [topStories, setTopStories] = useState(null);
  const classNames = useStyles(
    {
      heading: theme => ({
        ...theme.mixins.gutters()
      })
    },
    []
  );

  useEffect(async () => {
    setTopStories(await fetchTopStories());
  }, []);

  return (
    <PageSection noGutters>
      <Typography className={classNames.heading} component="h1" variant="h5">
        Hacker News Top Stories
      </Typography>
      {topStories === null ? <Spinner /> : null}
      <List>
        {(topStories || []).map(story => (
          <ListItem
            key={story.id}
            button
            component="a"
            href={story.url}
            target="_blank"
          >
            <ListItemText
              primary={story.title}
              secondary={<>by {story.by}</>}
            />
          </ListItem>
        ))}
      </List>
    </PageSection>
  );
}

export default HackerNews;
