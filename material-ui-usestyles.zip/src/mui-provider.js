/*
 * This will become a package of its own.
 *
 * Provides the glue to access the Material UI
 * theme from within the useStyles() styles.
 */

import { ThemeContext } from "@andywer/style-hook";
import { JssProvider } from "@andywer/style-api-jss";
import {
  MuiThemeProvider,
  createMuiTheme,
  withTheme
} from "@material-ui/core/styles";
import React from "react";

const ThemeContextAdapter = withTheme()(props => {
  return (
    <ThemeContext.Provider value={props.theme}>
      {props.children}
    </ThemeContext.Provider>
  );
});

function MuiProvider(props) {
  // Create a theme instance.
  const theme = props.theme || createMuiTheme({});

  return (
    <JssProvider>
      <MuiThemeProvider theme={theme}>
        <ThemeContextAdapter>{props.children}</ThemeContextAdapter>
      </MuiThemeProvider>
    </JssProvider>
  );
}

export default MuiProvider;
