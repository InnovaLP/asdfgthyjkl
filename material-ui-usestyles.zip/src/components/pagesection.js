import { useStyle } from "@andywer/style-hook";
import Paper from "@material-ui/core/Paper";
import React from "react";

function PageSection(props) {
  const className = useStyle(
    theme => ({
      flexGrow: 1,
      height: "100%",
      ...(props.noGutters ? {} : theme.mixins.gutters()),
      paddingTop: theme.spacing.unit * 2,
      paddingBottom: theme.spacing.unit * 2
    }),
    [props.noGutters]
  );
  return (
    <Paper className={`${className} ${props.className}`}>
      {props.children}
    </Paper>
  );
}

export default PageSection;
