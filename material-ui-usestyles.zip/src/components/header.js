import { useStyle } from "@andywer/style-hook";
import AppBar from "@material-ui/core/AppBar";
import Button from "@material-ui/core/Button";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import React from "react";
import { Link, withRouter } from "react-router-dom";

function Heading(props) {
  const className = useStyle({
    flexGrow: 1,
    color: "inherit"
  });
  return (
    <Typography className={className} variant="h6">
      {props.children}
    </Typography>
  );
}

const Header = withRouter(props => {
  // MUI styles take precedence over our styles if heading styles are declared here
  // Theory: The rendering order of sibling elements is back to front.
  //         Style precedence will be flawed if a right-side sibling of Heading
  //         renders the component that Heading is about to render first.
  const title =
    props.routeTitles[props.location.pathname] || props.location.pathname;
  return (
    <AppBar position="static">
      <Toolbar>
        <Heading>{title}</Heading>
        <Link to="/">
          <Button color="inherit">Home</Button>
        </Link>
        <Link to="/hacker-news">
          <Button color="inherit">Hacker News</Button>
        </Link>
      </Toolbar>
    </AppBar>
  );
});

export default Header;
