/*
 * Introducing React hooks - https://reactjs.org/docs/hooks-intro.html
 * useStyles() - https://github.com/andywer/react-usestyles
 */

import { useGlobalStyles } from "@andywer/style-hook";
import { createMuiTheme } from "@material-ui/core/styles";
import CssBaseline from "@material-ui/core/CssBaseline";
import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter as Router, Route } from "react-router-dom";

import Header from "./components/header";
import HackerNews from "./pages/hacker-news";
import Home from "./pages/home";
import MuiProvider from "./mui-provider";

const routeTitles = {
  "/": "Home",
  "/hacker-news": "Hacker News"
};

function GlobalStyles() {
  useGlobalStyles({
    "#root": {
      display: "flex",
      flexDirection: "column",
      width: "100%",
      height: "100%",
      minHeight: "100vh"
    },
    a: {
      color: "inherit",
      textDecoration: "none"
    }
  });
  return null;
}

const theme = createMuiTheme({
  typography: {
    useNextVariants: true
  }
});

function App() {
  return (
    <MuiProvider theme={theme}>
      <CssBaseline />
      <GlobalStyles />
      <Router>
        <>
          <Header routeTitles={routeTitles} />

          <Route path="/" exact component={Home} />
          <Route path="/hacker-news" exact component={HackerNews} />
        </>
      </Router>
    </MuiProvider>
  );
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
